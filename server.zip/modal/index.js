module.exports={
    requestFormModal:require("./homepageModal"),
    contactUsFormModal:require("./homepageModal/contactUs"),
}