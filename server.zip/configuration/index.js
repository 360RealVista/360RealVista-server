
module.exports={
    envConfig:require("./config.js")
}